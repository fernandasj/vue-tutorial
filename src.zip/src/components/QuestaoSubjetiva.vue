<template>
  <div class="field is-grouped">
    <p class="control is-expanded">
      <label class="label">Resposta esperada</label>
      <textarea class="textarea is-primary" rows="3" placeholder="Resposta do aluno" disabled></textarea>
    </p>
  </div>
</template>
<script>
export default {};
</script>
<style>
</style>
